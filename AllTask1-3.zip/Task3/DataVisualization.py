import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# Set a professional, clean visual style
sns.set_theme(style="whitegrid")
plt.rcParams["font.size"] = 12
plt.rcParams["axes.labelsize"] = 14
plt.rcParams["axes.titlesize"] = 16

# ==========================================
# 1. LOAD OR GENERATE DATA
# ==========================================
# Replace with your actual dataset path from Task 2
try:
    df = pd.read_csv("your_dataset.csv")
except FileNotFoundError:
    # Generating mock data to ensure the script runs seamlessly out-of-the-box
    np.random.seed(42)
    df = pd.DataFrame(
        {
            "Age": np.random.randint(22, 60, size=200),
            "Salary": np.random.normal(65000, 18000, size=200),
            "Experience_Years": np.random.randint(1, 20, size=200),
            "Department": np.random.choice(
                ["Engineering", "HR", "Sales", "Marketing"],
                size=200,
                p=[0.4, 0.1, 0.3, 0.2],
            ),
            "Performance_Rating": np.random.choice(
                ["Low", "Medium", "High"], size=200, p=[0.15, 0.50, 0.35]
            ),
        }
    )

print("Data ready for visualization!")

# ==========================================
# VISUAL 1: Distribution of a Numerical Variable
# ==========================================
plt.figure(figsize=(10, 5))
sns.histplot(data=df, x="Salary", kde=True, color="#2b5c8f", bins=20)
plt.title("Distribution of Employee Salaries", pad=15)
plt.xlabel("Annual Salary ($)")
plt.ylabel("Employee Count")
plt.tight_layout()
plt.show()  # Displays instantly in Jupyter Notebook

# ==========================================
# VISUAL 2: Categorical Comparison (Bar Chart)
# ==========================================
plt.figure(figsize=(10, 5))
# Calculate average salary per department for a clean storyline
dept_salary = (
    df.groupby("Department")["Salary"].mean().reset_index().sort_values(by="Salary")
)

sns.barplot(
    data=dept_salary, x="Department", y="Salary", palette="Blues_d", hue="Department", legend=False
)
plt.title("Average Salary Across Different Departments", pad=15)
plt.xlabel("Department")
plt.ylabel("Mean Salary ($)")
plt.tight_layout()
plt.show()

# ==========================================
# VISUAL 3: Relationships & Trends (Scatter Plot)
# ==========================================
plt.figure(figsize=(10, 6))
sns.scatterplot(
    data=df,
    x="Experience_Years",
    y="Salary",
    hue="Performance_Rating",
    style="Performance_Rating",
    palette="deep",
    s=100,
    alpha=0.8,
)
plt.title("Salary vs. Years of Experience by Performance Rating", pad=15)
plt.xlabel("Years of Experience")
plt.ylabel("Annual Salary ($)")
plt.legend(title="Performance Rating", bbox_to_anchor=(1.05, 1), loc="upper left")
plt.tight_layout()
plt.show()

# ==========================================
# VISUAL 4: Composition & Subplots (Dashboard Feel)
# ==========================================
fig, axes = plt.subplots(1, 2, figsize=(16, 6))

# Subplot A: Pie chart / Count plot for Department representation
sns.countplot(
    data=df,
    y="Department",
    order=df["Department"].value_counts().index,
    ax=axes[0],
    palette="pastel",
    hue="Department",
    legend=False,
)
axes[0].set_title("Employee Distribution by Department")
axes[0].set_xlabel("Count")

# Subplot B: Box plot to see spread of Salary by Performance
sns.boxplot(
    data=df,
    x="Performance_Rating",
    y="Salary",
    order=["Low", "Medium", "High"],
    ax=axes[1],
    palette="Set2",
    hue="Performance_Rating",
    legend=False,
)
axes[1].set_title("Salary Spread Across Performance Levels")
axes[1].set_xlabel("Performance Rating")
axes[1].set_ylabel("Salary ($)")

plt.suptitle("Executive HR Insights Dashboard", fontsize=18, weight="bold", y=1.02)
plt.tight_layout()
plt.show()