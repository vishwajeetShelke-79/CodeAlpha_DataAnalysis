import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# Set visual style for data visualizations
sns.set_theme(style="whitegrid")
plt.rcParams["figure.figsize"] = (10, 6)

# ==========================================
# 1. LOAD THE DATASET
# ==========================================
# Replace 'your_dataset.csv' with your actual file path
try:
    df = pd.read_csv("your_dataset.csv")
    print("Dataset loaded successfully!")
except FileNotFoundError:
    print(
        "File not found. Generating a mock dataset for demonstration purposes..."
    )
    # Creating a dummy dataset if no file is provided
    np.random.seed(42)
    df = pd.DataFrame(
        {
            "Age": np.random.randint(18, 70, size=100),
            "Income": np.random.normal(55000, 15000, size=100),
            "Score": np.random.uniform(1, 100, size=100),
            "Department": np.random.choice(
                ["Sales", "HR", "Tech", "Marketing"], size=100
            ),
            "Joined_Year": np.random.choice(
                [2021, 2022, 2023, 2024], size=100
            ),
        }
    )
    # Intentionally introducing anomalies/missing values for demonstration
    df.loc[5:10, "Income"] = np.nan
    df.loc[20, "Age"] = 150  # Outlier

# ==========================================
# 2. EXPLORE DATA STRUCTURE & VARIABLES
# ==========================================
print("\n--- 📊 DATA STRUCTURE OVERVIEW ---")
print(f"Shape of the dataset (Rows, Columns): {df.shape}")

print("\n--- ℹ️ DATA TYPES & MISSING VALUES ---")
print(df.info())

print("\n--- 📝 STATISTICAL SUMMARY (NUMERICAL) ---")
print(df.describe())

print("\n--- 🗂️ CARDINALITY OF CATEGORICAL COLUMNS ---")
for col in df.select_dtypes(include=["object", "category"]).columns:
    print(f"\nValue counts for '{col}':")
    print(df[col].value_counts())

# ==========================================
# 3. DETECT DATA ISSUES & ANOMALIES
# ==========================================
print("\n--- 🚨 IDENTIFYING MISSING VALUES ---")
missing_info = df.isnull().sum()
print(missing_info[missing_info > 0] if missing_info.sum() > 0 else "No missing values found.")

# Handling Missing Values (Example: Imputing with median)
numeric_cols = df.select_dtypes(include=[np.number]).columns
for col in numeric_cols:
    if df[col].isnull().sum() > 0:
        median_val = df[col].median()
        df[col].fillna(median_val, inplace=True)
        print(f"Imputed missing values in '{col}' with median: {median_val}")

# Outlier Detection via Boxplot (Saved as Image)
print("\n--- 📈 VISUALIZING OUTLIERS & DISTRIBUTIONS ---")
plt.figure()
sns.boxplot(data=df.select_dtypes(include=[np.number]))
plt.title("Boxplot for Outlier Detection")
plt.savefig("outliers_boxplot.png")
plt.close()
print("Outlier boxplot saved as 'outliers_boxplot.png'.")

# ==========================================
# 4. IDENTIFY TRENDS & PATTERNS (CORRELATION)
# ==========================================
print("\n--- 🔄 CORRELATION ANALYSIS ---")
# Select only numerical features for correlation matrix
numerical_df = df.select_dtypes(include=[np.number])

if not numerical_df.empty:
    corr_matrix = numerical_df.corr()
    print(corr_matrix)

    # Heatmap visualization
    plt.figure(figsize=(8, 6))
    sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5)
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig("correlation_heatmap.png")
    plt.close()
    print("Correlation heatmap saved as 'correlation_heatmap.png'.")

# ==========================================
# 5. HYPOTHESIS TESTING & VISUALIZATION
# ==========================================
# Example pattern tracking: How does Income vary across Departments?
if "Department" in df.columns and "Income" in df.columns:
    plt.figure()
    sns.barplot(x="Department", y="Income", data=df, estimator=np.mean, errorbar="sd")
    plt.title("Average Income distribution by Department")
    plt.ylabel("Mean Income")
    plt.tight_layout()
    plt.savefig("income_by_department.png")
    plt.close()
    print("Trend chart saved as 'income_by_department.png'.")

print("\n🎉 EDA Task Execution Completed!")